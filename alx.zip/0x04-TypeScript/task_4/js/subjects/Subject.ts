/// <reference path='Teacher.ts' />

namespace Subjects {
  export class Subjects {
    teacher: Teacher;

    setTeacher(teacher: Teacher) {
      this.teacher = teacher;
    }
  }
}
